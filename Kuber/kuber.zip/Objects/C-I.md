CSI -> interface for write on disk
CRI -> Interface for manage runtime resources
CNI -> Interface for manage network

C-I use namespace and CGroup (Linux concepts) for manage resource and disk